package itacademy.lambas.introduction;

@FunctionalInterface
public interface User {
    String getName();
}
